

<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('main'); ?>
  <div class="form-container">
    <h1 class="form-title"><?php echo e($pageTitle); ?></h1>
    <form
      class="form"
      method="POST"
      action="<?php echo e(route('tasks.destroy', ['id' => $task->id])); ?>"
    >
      <?php echo method_field('DELETE'); ?>
      <?php echo csrf_field(); ?>
      <p>You are going to delete <strong>"<?php echo e($task->name); ?>"</strong></p>
        <p>Are you sure?</p>
        <button type="submit" class="form-button">
          Yes, delete it forever
        </button>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kanban-app\resources\views/tasks/delete.blade.php ENDPATH**/ ?>