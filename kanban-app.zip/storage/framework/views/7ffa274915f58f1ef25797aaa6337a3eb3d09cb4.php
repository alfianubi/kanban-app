

<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('main'); ?>
  <div class="form-container">
    <h1 class="form-title"><?php echo e($pageTitle); ?></h1>
    <form
      class="form"
      method="POST"
      action="<?php echo e(route('roles.store')); ?>"
    >
      <?php echo csrf_field(); ?>
      <div class="form-item">
        <label>Role Name:</label>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <input
          class="form-input"
          type="text"
          value="<?php echo e(old('name')); ?>"
          name="name"
        >
      </div>


      <div class="form-item">
        <label>Permissions:</label>

        <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div>
            <input
              type="checkbox"
              name="permissionIds[]"
              value="<?php echo e($permission->id); ?>"
            >
            <label for="<?php echo e($permission->name); ?>">
              <?php echo e($permission->description); ?>

            </label>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <button type="submit" class="form-button">Submit</button>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kanban-app\resources\views/roles/create.blade.php ENDPATH**/ ?>