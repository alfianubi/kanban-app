

<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('main'); ?>
  <div class="form-container">
    <h1 class="form-title"><?php echo e($pageTitle); ?></h1>
    <form class="form"  method="POST" action="<?php echo e(route('tasks.update',['id'=>$task->id])); ?>">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>

      <div class="form-item">
        <label>Name:</label>
        <input class="form-input" type="text" value="<?php echo e(old('name', $task->name)); ?>" name="name">
      </div>

      <div class="form-item">
        <label>Detail:</label>
        <textarea class="form-text-area" name="detail"><?php echo e(old('detail', $task->detail)); ?></textarea>
      </div>

      <div class="form-item">
        <label>Due Date:</label>
        <input class="form-input" type="date" name="due_date" value="<?php echo e(old('due_date', $task->due_date)); ?>">
      </div>
 
      <div class="form-item">
        <label>Progress:</label>
        <select class="form-input" name='status'>
          <option <?php if(old('status', $task->status) == 'not_started'): ?> selected <?php endif; ?> value="not_started">
            Not Started
          </option>
          <option <?php if(old('status', $task->status) == 'in_progress'): ?> selected <?php endif; ?> value="in_progress">
            In Progress
          </option>
          <option <?php if(old('status', $task->status) == 'in_review'): ?> selected <?php endif; ?> value="in_review">
            Waiting/In Review
          </option>
          <option <?php if(old('status', $task->status) == 'completed'): ?> selected <?php endif; ?> value="completed">
            Completed
          </option>
        </select>
      </div>
      <button type="submit" class="form-button">Submit</button>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kanban-app\resources\views/tasks/edit.blade.php ENDPATH**/ ?>