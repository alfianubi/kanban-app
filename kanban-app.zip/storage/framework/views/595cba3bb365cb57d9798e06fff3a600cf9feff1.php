<div class="task-progress-column">
  <div class="task-progress-column-heading">
    <h2><?php echo e($title); ?></h2>    
      <a href="<?php echo e(route('tasks.create', ['status' => $status])); ?>" style="text-decoration: none; font-size: 24px;">+</a>
  </div>
  <div>
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo $__env->make('partials.task_card', [
        'task' => $task,
        'leftStatus' => $leftStatus,
        'rightStatus' => $rightStatus,        
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div><?php /**PATH C:\xampp\htdocs\kanban-app\resources\views/partials/task_column.blade.php ENDPATH**/ ?>