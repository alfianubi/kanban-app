<div class="sidebar">
  <div class="sidebar-container">
    <a class="sidebar-link" href="<?php echo e(route('home')); ?>"> <!-- Diperbarui -->
      <span class="material-icons sidebar-icon">home</span>
        <p class="sidebar-text">Home</p>
    </a>
  <!-- Diperbarui -->
    <a class="sidebar-link" href="<?php echo e(route('tasks.index')); ?>">
      <span class="material-icons sidebar-icon">list</span>
        <p class="sidebar-text">Task List</p>
    </a>
    <!-- membuat tautan menuju task progress -->
    <a href="<?php echo e(route('tasks.progress')); ?>" class="sidebar-link">
      <span class="material-icons sidebar-icon">check_box</span>
      <p class=""sidebar-text>Task Progress</p>
    </a>
    <a class="sidebar-link" href="<?php echo e(route('roles.index')); ?>">
      <span class="material-icons sidebar-icon">settings</span>
      <p class="sidebar-text">Roles</p>
    </a>
    <?php if(Auth::check()): ?>
      <a class="sidebar-link" href=""
        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <span class="material-icons sidebar-icon">logout</span>
        <p class="sidebar-text">Logout</p>
      </a>
      <form id="logout-form" action="<?php echo e(route('auth.logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
      </form>
    <?php endif; ?>
  </div>
</div><?php /**PATH C:\xampp\htdocs\kanban-app\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>