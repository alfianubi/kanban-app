<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
  <title><?php echo $__env->yieldContent('pageTitle'); ?></title>
</head>

<body>
  <!-- Memperbarui HTML code dibawah -->        
    <div class="container">
        <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <div class="main">
            <?php echo $__env->yieldContent('main'); ?>
        </div>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\kanban-app\resources\views/layouts/master.blade.php ENDPATH**/ ?>