

<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('main'); ?>
    <!-- import task model -->
    <?php
        use App\Models\Task;
    ?>
  <div class="task-list-container">
    <h1 class="task-list-heading"><?php echo e($pageTitle); ?></h1>

    <div class="task-progress-board">
      <?php echo $__env->make('partials.task_column', [
        'title' => 'Not Started',
        'tasks' => $tasks['not_started'],
        'leftStatus' => null,
        'rightStatus' => 'in_progress',        
        'status' => 'not_started',
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('partials.task_column', [
        'title' => 'In Progress',
        'tasks' => $tasks['in_progress'],
        'leftStatus' => 'not_started',
        'rightStatus' => 'in_review',
        'status' => 'in_progress',
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('partials.task_column', [
        'title' => 'In Review',
        'tasks' => $tasks['in_review'],
        'leftStatus' => 'in_progress',
        'rightStatus' => 'completed',
        'status' => 'in_review',
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('partials.task_column', [
        'title' => 'Completed',
        'tasks' => $tasks['completed'],
        'leftStatus' => 'in_review',
        'rightStatus' => null,
        'status' => 'completed',
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kanban-app\resources\views/tasks/progress.blade.php ENDPATH**/ ?>