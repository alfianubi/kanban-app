<div class="task-progress-card">
    <div class="task-progress-card-left">
        <!-- tambah aksi untuk update -->


      <?php if($task->status == 'completed'): ?>
        <div class="material-icons task-progress-card-top-checked">check_circle</div>
      <?php else: ?>
      <a href="<?php echo e(route('tasks.finish_progress', ['id' => $task->id ])); ?>" style="text-decoration: none;" class="material-icons task-progress-card-top-check">
        check_circle
      </a>
              
      <?php endif; ?>
      <a href="<?php echo e(route('tasks.edit', ['id' => $task->id])); ?>" class="material-icons task-progress-card-top-edit">more_vert</a>
    </div>
    <p class="task-progress-card-title"><?php echo e($task->name); ?></p>
        <div>
            <p><?php echo e($task->detail); ?></p>
        </div>
    <div>
      <p>Due on <?php echo e($task->due_date); ?></p>
    </div>
    <!-- Tambahkan code dibawah -->
    <div>
      <p>Owner: <strong><?php echo e($task->user->name); ?></strong></p>
    </div>
      <div class="<?php if($leftStatus): ?> task-progress-card-left <?php else: ?> task-progress-card-right <?php endif; ?>">
        <?php if($leftStatus): ?>
          <!-- Mengapit "button" dengan "form" -->
          <form action="<?php echo e(route('tasks.move', ['id' => $task->id, 'status' => $leftStatus])); ?>" method="POST">
            <?php echo method_field('patch'); ?>
            <?php echo csrf_field(); ?>
            <button class="material-icons">chevron_left</button>
          </form>
        <?php endif; ?>
    
        <?php if($rightStatus): ?>
          <!-- Mengapit "button" dengan "form" -->
          <form action="<?php echo e(route('tasks.move', ['id' => $task->id, 'status' => $rightStatus])); ?>" method="POST">
            <?php echo method_field('patch'); ?>
            <?php echo csrf_field(); ?>
            <button class="material-icons">chevron_right</button>
          </form>
        <?php endif; ?>
      </div>
    </div><?php /**PATH C:\xampp\htdocs\kanban-app\resources\views/partials/task_card.blade.php ENDPATH**/ ?>