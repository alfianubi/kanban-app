

<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('main'); ?>
  <div class="task-list-container">
    <h1 class="task-list-heading"><?php echo e($pageTitle); ?></h1>
    <div class="task-list-task-buttons">
      <a href="<?php echo e(route('roles.create')); ?>">
        <button  class="task-list-button">
          <span class="material-icons">add</span>Add Role
        </button>
      </a>
    </div>

    <div>
      <div class="task-list-table-head">
        <div class="task-list-header-task-name">Role</div>
        <div class="task-list-header-detail">Permissions</div>
      </div>

      <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="table-body">
        <div class="table-body-role-name">
          <p><?php echo e($role->name); ?></p>
        </div>
        <div class="table-body-permission">
          <ul>
            <?php $__currentLoopData = $role->permissions->sort(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="table-body-permission-item">
                <?php echo e($permission->description); ?>

              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <div class="table-body-links">
          <a href="<?php echo e(route('roles.edit', ['id' => $role->id])); ?>">Edit</a>
          <a href="<?php echo e(route('roles.delete', ['id' => $role->id])); ?>">Delete</a>
        </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kanban-app\resources\views/roles/index.blade.php ENDPATH**/ ?>