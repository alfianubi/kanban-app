

<!-- judul title head -->
<?php $__env->startSection('pageTitle', $pageTitle); ?>
<?php $__env->startSection('pageTitle', 'Home'); ?> 

<?php $__env->startSection('main'); ?>
  <div class="task-list-container">
    <h1 class="task-list-heading">Task List</h1>
    <!-- button add task -->
    <div class="task-list-task-buttons">
      <a href="<?php echo e(route('tasks.create')); ?>">
        <button  class="task-list-button">
          <span class="material-icons">add</span>Add task
        </button>
      </a>
    </div>

    <div class="task-list-table-head">
      <div class="task-list-header-task-name">Task Name</div>
      <div class="task-list-header-detail">Detail</div>
      <div class="task-list-header-due-date">Due Date</div>
      <div class="task-list-header-progress">Progress</div>
      <div class="task-list-header-owner-name">Owner</div>
    </div>

    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="table-body">
        <div class="table-body-task-name">
          <?php if($task->status == 'completed'): ?>
            <div class="material-icons task-progress-card-top-checked">check_circle</div>
          <?php else: ?>
          <a href="<?php echo e(route('tasks.finish_tasklist', ['id' => $task->id ])); ?>" style="text-decoration: none;" class="material-icons task-progress-card-top-check">
            check_circle
          </a>
          <?php endif; ?>          
          <?php echo e($task->name); ?>

        </div>
        <div class="table-body-detail"> <?php echo e($task->detail); ?> </div>
        <div class="table-body-due-date"> <?php echo e($task->due_date); ?> </div>
        <div class="table-body-progress">
          <?php switch($task->status):
            case ('in_progress'): ?>
              In Progress
              <?php break; ?>
            <?php case ('in_review'): ?>
              Waiting/In Review
              <?php break; ?>
            <?php case ('completed'): ?>
              Completed
              <?php break; ?>
            <?php default: ?>
              Not Started
          <?php endswitch; ?>
        </div>
        <!-- Tambahkan code ini -->
        <div class="table-body-owner-name"><?php echo e($task->user->name); ?></div>
        <!-- button edit -->
        <div class="table-body-links">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $task)): ?>
            <a href="<?php echo e(route('tasks.edit', ['id' => $task->id])); ?>">Edit</a>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $task)): ?>
            <a href="<?php echo e(route('tasks.delete', ['id' => $task->id])); ?>">Delete</a>
          <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kanban-app\resources\views/tasks/index.blade.php ENDPATH**/ ?>