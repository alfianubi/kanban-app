

<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('main'); ?>
  <div class="form-container">
    <h1 class="form-title"><?php echo e($pageTitle); ?></h1>
    <form
      class="form"
      method="POST"
      action="<?php echo e(route('auth.signup')); ?>"
    >
      <?php echo csrf_field(); ?>

      <div class="form-item">
        <label>Name:</label>
        <input
          class="form-input" 
          type="text" 
          value="<?php echo e(old('name')); ?>"
          name="name"
        >
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="form-item">
        <label>Email:</label>
        <input
          class="form-input"
          type="text"
          value="<?php echo e(old('email')); ?>"
          name="email"
        >
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="form-item">
        <label>Password:</label>
        <input
          class="form-input"
          type="password"
          value=""
          name="password"
        >
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <button type="submit" class="form-button">Submit</button>
    </form>
    <!-- Tamabahkan code berikut ini -->
    <p class="auth-link">Already have an account? <a href="<?php echo e(route('auth.login')); ?>">Login here</a></p>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kanban-app\resources\views/auth/signup_form.blade.php ENDPATH**/ ?>